import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import timesheetService from '../services/timesheetService';
import './UpdateTimesheet.css';

function UpdateTimesheet() {
    const [timesheets, setTimesheets] = useState([]);
    const [date, setDate] = useState('');
    const [projectName, setProjectName] = useState('');
    const [startTime, setStartTime] = useState('');
    const [endTime, setEndTime] = useState('');
    const [comments, setComments] = useState('');
    const [showPopup, setShowPopup] = useState(false);
    const [hoveredTimesheet, setHoveredTimesheet] = useState(null);
    const [currentMonth, setCurrentMonth] = useState(new Date().getMonth());
    const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
    const { empId } = useAuth(); // Get empId from context

    useEffect(() => {
        if (empId) {
            loadTimesheets();
        } else {
            alert('Employee ID not found');
        }
    }, [empId, currentMonth, currentYear]);

    const loadTimesheets = async () => {
        try {
            const response = await timesheetService.getTimesheets(empId);
            setTimesheets(response.data);
        } catch (error) {
            alert("Error loading timesheets");
        }
    };

    const handleAddTimesheet = async (e) => {
        e.preventDefault();

        const startTimeObj = new Date(`${date}T${startTime}`);
        const endTimeObj = new Date(`${date}T${endTime}`);
        const hours = (endTimeObj - startTimeObj) / (1000 * 60 * 60);

        if (hours <= 0) {
            alert("End time must be after start time");
            return;
        }

        const dayTimesheets = timesheets.filter(t => t.date === date);
        const totalHoursForDay = dayTimesheets.reduce((sum, t) => sum + parseFloat(t.total_hours), 0) + hours;

        if (totalHoursForDay > 24) {
            alert("Total hours for the day exceed 24 hours. Please adjust the times.");
            return;
        }

        try {
            await timesheetService.addTimesheet(empId, date, projectName, startTime, endTime, comments);
            loadTimesheets();
            setShowPopup(false);
        } catch (error) {
            alert("Error adding timesheet");
        }
    };

    const getRandomColor = () => {
        const letters = '0123456789ABCDEF';
        let color = '#';
        for (let i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    };

    const handlePrevMonth = () => {
        setCurrentMonth(prevMonth => prevMonth === 0 ? 11 : prevMonth - 1);
        setCurrentYear(prevYear => currentMonth === 0 ? prevYear - 1 : prevYear);
    };

    const handleNextMonth = () => {
        setCurrentMonth(prevMonth => prevMonth === 11 ? 0 : prevMonth + 1);
        setCurrentYear(prevYear => currentMonth === 11 ? prevYear + 1 : prevYear);
    };

    const renderCalendar = () => {
        const firstDay = new Date(currentYear, currentMonth, 1).getDay();
        const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
        const calendar = [];
        let dayCount = 1;

        for (let i = 0; i < 6; i++) {
            const week = [];
            for (let j = 0; j < 7; j++) {
                if ((i === 0 && j < firstDay) || dayCount > daysInMonth) {
                    week.push(<td key={`${i}-${j}`} className="calendar-cell empty"></td>);
                } else {
                    const dateString = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(dayCount).padStart(2, '0')}`;
                    const dayTimesheets = timesheets.filter(t => t.date === dateString);
                    const isFutureDate = new Date(dateString) >= new Date().setHours(0, 0, 0, 0);
                    const isSunday = j === 0;

                    week.push(
                        <td key={`${i}-${j}`} className="calendar-cell date-cell-container">
                            <div className={`date-cell ${isFutureDate ? 'locked' : ''}`}>
                                <span className="date-number">{dayCount}</span>
                                {isSunday ? (
                                    <div className="week-off">
                                        <span role="img" aria-label="smiley">😊</span> Week Off
                                    </div>
                                ) : (
                                    <div className="timesheet-circles">
                                        {dayTimesheets.map((timesheet, index) => (
                                            <div
                                                key={index}
                                                className="total-hours-circle"
                                                style={{ backgroundColor: getRandomColor() }}
                                                onMouseEnter={() => setHoveredTimesheet(timesheet)}
                                                onMouseLeave={() => setHoveredTimesheet(null)}
                                            >
                                                {Math.round(timesheet.total_hours)}
                                            </div>
                                        ))}
                                    </div>
                                )}
                                {!isFutureDate && !isSunday && (
                                    <button
                                        className="plus-button"
                                        onClick={() => {
                                            setDate(dateString);
                                            setShowPopup(true);
                                        }}
                                    >
                                        +
                                    </button>
                                )}
                            </div>
                        </td>
                    );
                    dayCount++;
                }
            }
            calendar.push(<tr key={i}>{week}</tr>);
        }

        return calendar;
    };

    return (
        <div className="update-timesheet">
            <div className="header">
                <h3>{`${currentYear}-${String(currentMonth + 1).padStart(2, '0')}`}</h3>
                <p>Employee ID: {empId}</p>
                <div className="month-navigation">
                    <button onClick={handlePrevMonth}>Previous</button>
                    <button onClick={handleNextMonth}>Next</button>
                </div>
            </div>
            <table className="calendar-table">
                <thead>
                    <tr>
                        <th>Sun</th>
                        <th>Mon</th>
                        <th>Tue</th>
                        <th>Wed</th>
                        <th>Thu</th>
                        <th>Fri</th>
                        <th>Sat</th>
                    </tr>
                </thead>
                <tbody>
                    {renderCalendar()}
                </tbody>
            </table>
            {showPopup && (
                <div className="popup show">
                    <div className="popup-content">
                        <h3>Add Timesheet Entry</h3>
                        <form onSubmit={handleAddTimesheet}>
                            <label>
                                Date:
                                <input
                                    type="date"
                                    value={date}
                                    onChange={(e) => setDate(e.target.value)}
                                    max={new Date().toISOString().split('T')[0]}
                                    required
                                />
                            </label>
                            <label>
                                Project Name:
                                <input
                                    type="text"
                                    value={projectName}
                                    onChange={(e) => setProjectName(e.target.value)}
                                    required
                                />
                            </label>
                            <label>
                                Start Time:
                                <input
                                    type="time"
                                    value={startTime}
                                    onChange={(e) => setStartTime(e.target.value)}
                                    required
                                />
                            </label>
                            <label>
                                End Time:
                                <input
                                    type="time"
                                    value={endTime}
                                    onChange={(e) => setEndTime(e.target.value)}
                                    required
                                />
                            </label>
                            <label>
                                Comments:
                                <textarea
                                    value={comments}
                                    onChange={(e) => setComments(e.target.value)}
                                ></textarea>
                            </label>
                            <button type="submit">Save</button>
                            <button type="button" onClick={() => setShowPopup(false)}>Cancel</button>
                        </form>
                    </div>
                </div>
            )}
            {hoveredTimesheet && (
                <div className="hover-popup" style={{ top: '50px', left: '50px' }}> {/* Adjust position as needed */}
                    <p>Date: {hoveredTimesheet.date}</p>
                    <p>Project: {hoveredTimesheet.project_name}</p>
                    <p>Start Time: {hoveredTimesheet.start_time}</p>
                    <p>End Time: {hoveredTimesheet.end_time}</p>
                    <p>Total Hours: {hoveredTimesheet.total_hours}</p>
                    <p>Comments: {hoveredTimesheet.comments}</p>
                </div>
            )}
        </div>
    );
}

export default UpdateTimesheet;
