from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import Employee, Timesheet

class EmployeeAdmin(BaseUserAdmin):
    model = Employee
    list_display = ('emp_id', 'emp_name', 'email', 'role', 'is_staff', 'is_superuser', 'is_active')
    list_filter = ('role', 'is_active', 'is_staff', 'is_superuser')

    fieldsets = (
        (None, {'fields': ('emp_id', 'emp_name', 'email', 'password')}),
        ('Permissions', {'fields': ('is_active', 'is_staff', 'is_superuser', 'role')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('emp_id', 'emp_name', 'email', 'password1', 'password2', 'is_active', 'is_staff', 'is_superuser', 'role')}
        ),
    )
    search_fields = ('emp_id', 'emp_name', 'email')
    ordering = ('emp_id',)
    filter_horizontal = ()

    def save_model(self, request, obj, form, change):
        if not change:  # Handle user creation
            obj.set_password(form.cleaned_data['password1'])
        obj.save()

class TimesheetAdmin(admin.ModelAdmin):
    list_display = ('employee', 'start_time', 'end_time', 'total_hours', 'status')
    list_filter = ('status',)
    search_fields = ('employee__emp_id', 'employee__emp_name', 'description')
    ordering = ('-start_time',)

admin.site.register(Employee, EmployeeAdmin)
admin.site.register(Timesheet, TimesheetAdmin)