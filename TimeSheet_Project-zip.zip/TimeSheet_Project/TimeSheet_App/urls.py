from django.urls import path
from .views import RegisterView, LoginView, TimesheetView, LeadTimesheetView, ManagerTimesheetView, ResetPasswordView, UserDetailsView

urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('login/', LoginView.as_view(), name='login'),
    path('timesheets/', TimesheetView.as_view(), name='timesheets'),
    path('lead-timesheets/', LeadTimesheetView.as_view(), name='lead-timesheets'),
    path('manager-timesheets/', ManagerTimesheetView.as_view(), name='manager-timesheets'),
    path('reset-password/', ResetPasswordView.as_view(), name='reset-password'),
    path('user-details/', UserDetailsView.as_view(), name='user-details'),
]
