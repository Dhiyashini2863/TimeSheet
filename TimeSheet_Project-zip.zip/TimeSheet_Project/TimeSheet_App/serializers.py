from rest_framework import serializers
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.contrib.auth.password_validation import validate_password
from .models import Timesheet

User = get_user_model()

class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = ['emp_id', 'emp_name', 'email', 'password']

    def create(self, validated_data):
        user = User.objects.create_user(
            emp_id=validated_data['emp_id'],
            emp_name=validated_data['emp_name'],
            email=validated_data['email'],
            password=validated_data['password']
        )
        return user

class LoginSerializer(serializers.Serializer):
    emp_id = serializers.CharField()
    password = serializers.CharField()

class TimesheetSerializer(serializers.ModelSerializer):
    class Meta:
        model = Timesheet
        fields = ['id', 'employee', 'date', 'project_name', 'start_time', 'end_time', 'total_hours', 'description', 'comments', 'status']

    def validate(self, data):
        if data['start_time'] >= data['end_time']:
            raise serializers.ValidationError("End time must be after start time.")
        return data

    def create(self, validated_data):
        validated_data['total_hours'] = (validated_data['end_time'] - validated_data['start_time']).total_seconds() / 3600
        return super().create(validated_data)


class ResetPasswordSerializer(serializers.Serializer):
    emp_id = serializers.CharField(max_length=100)
    new_password = serializers.CharField(max_length=128)

    def validate_emp_id(self, value):
        if not User.objects.filter(emp_id=value).exists():
            raise serializers.ValidationError("Employee ID does not exist.")
        return value

    def validate_new_password(self, value):
        try:
            validate_password(value)
        except ValidationError as e:
            raise serializers.ValidationError(e.messages)
        return value
