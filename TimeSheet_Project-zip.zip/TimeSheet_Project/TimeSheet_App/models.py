from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.utils.translation import gettext_lazy as _

class EmployeeManager(BaseUserManager):
    def create_user(self, emp_id, emp_name, email, password=None, role='employee'):
        if not emp_id:
            raise ValueError('The Employee ID must be set')
        if not email:
            raise ValueError('The Email must be set')
        email = self.normalize_email(email)
        user = self.model(emp_id=emp_id, emp_name=emp_name, email=email, role=role)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, emp_id, emp_name, email, password=None):
        user = self.create_user(emp_id, emp_name, email, password, role='admin')
        user.is_staff = True
        user.is_superuser = True
        user.save(using=self._db)
        return user

class Employee(AbstractBaseUser, PermissionsMixin):
    emp_id = models.CharField(max_length=10, unique=True)
    emp_name = models.CharField(max_length=100)
    email = models.EmailField(max_length=255, unique=True)
    role = models.CharField(max_length=50, default='employee')
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)

    objects = EmployeeManager()

    USERNAME_FIELD = 'emp_id'
    REQUIRED_FIELDS = ['emp_name', 'email']

    def __str__(self):
        return self.emp_name
    
class Timesheet(models.Model):
    employee = models.ForeignKey(Employee, related_name='timesheets', on_delete=models.CASCADE)
    date = models.DateField()
    project_name = models.CharField(max_length=255)
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    total_hours = models.FloatField()
    description = models.TextField()
    comments = models.TextField(blank=True, null=True)  # Add this field
    status = models.CharField(max_length=10, choices=[('pending', 'Pending'), ('approved', 'Approved'), ('rejected', 'Rejected')], default='pending')

    def __str__(self):
        return f'Timesheet for {self.employee.emp_id} on {self.date}'