from rest_framework import generics, serializers
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from .models import Employee, Timesheet
from rest_framework.exceptions import ValidationError
from .serializers import RegisterSerializer, LoginSerializer, TimesheetSerializer, ResetPasswordSerializer
from django.contrib.auth import get_user_model

User = get_user_model()

class RegisterView(generics.CreateAPIView):
    serializer_class = RegisterSerializer
    permission_classes = [AllowAny]

class LoginView(generics.GenericAPIView):
    serializer_class = LoginSerializer
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        emp_id = serializer.validated_data['emp_id']
        password = serializer.validated_data['password']
        user = Employee.objects.filter(emp_id=emp_id).first()

        if user and user.check_password(password):
            refresh = RefreshToken.for_user(user)
            return Response({
                'access': str(refresh.access_token),
                'refresh': str(refresh),
                'role': user.role
            })
        return Response({'error': 'Invalid credentials'}, status=401)

class TimesheetView(generics.ListCreateAPIView):
    serializer_class = TimesheetSerializer

    def get_queryset(self):
        emp_id = self.request.query_params.get('emp', None)
        if emp_id:
            return Timesheet.objects.filter(employee__emp_id=emp_id)
        return Timesheet.objects.all()

    def perform_create(self, serializer):
        emp_id = self.request.data.get('emp')
        try:
            employee = Employee.objects.get(emp_id=emp_id)
            # Exclude status when creating a new timesheet
            serializer.save(employee=employee, status='pending')
        except Employee.DoesNotExist:
            raise ValidationError("Employee with this ID does not exist.")

class LeadTimesheetView(generics.ListCreateAPIView):
    serializer_class = TimesheetSerializer

    def get_queryset(self):
        user = self.request.user
        if user.role == 'lead':
            return Timesheet.objects.all()
        return Timesheet.objects.none()

class ManagerTimesheetView(generics.ListCreateAPIView):
    serializer_class = TimesheetSerializer

    def get_queryset(self):
        user = self.request.user
        if user.role == 'manager':
            return Timesheet.objects.all()
        return Timesheet.objects.none()

class ResetPasswordView(generics.GenericAPIView):
    serializer_class = ResetPasswordSerializer
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        emp_id = serializer.validated_data['emp_id']
        new_password = serializer.validated_data['new_password']
        user = Employee.objects.filter(emp_id=emp_id).first()

        if user:
            user.set_password(new_password)
            user.save()
            return Response({'message': 'Password reset successful'})
        return Response({'error': 'Invalid employee ID'}, status=400)

class UserDetailsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = {
            'emp_id': request.user.emp_id,
            'emp_name': request.user.emp_name,
        }
        return Response(user)

