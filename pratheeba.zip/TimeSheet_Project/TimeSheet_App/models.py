# from django.db import models
# from django.contrib.auth import get_user_model
# from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
# from django.utils.translation import gettext_lazy as _

# class EmployeeManager(BaseUserManager):
#     def create_user(self, emp_id, emp_name, email, password=None, role='employee'):
#         if not emp_id:
#             raise ValueError('The Employee ID must be set')
#         if not email:
#             raise ValueError('The Email must be set')
#         email = self.normalize_email(email)
#         user = self.model(emp_id=emp_id, emp_name=emp_name, email=email, role=role)
#         user.set_password(password)
#         user.save(using=self._db)
#         return user

#     def create_superuser(self, emp_id, emp_name, email, password=None):
#         user = self.create_user(emp_id, emp_name, email, password, role='admin')
#         user.is_staff = True
#         user.is_superuser = True
#         user.save(using=self._db)
#         return user

# class Employee(AbstractBaseUser, PermissionsMixin):
#     emp_id = models.CharField(max_length=10, unique=True)
#     emp_name = models.CharField(max_length=100)
#     email = models.EmailField(max_length=255, unique=True)
#     role = models.CharField(max_length=50, default='employee')
#     is_active = models.BooleanField(default=True)
#     is_staff = models.BooleanField(default=False)
#     is_superuser = models.BooleanField(default=False)

#     objects = EmployeeManager()

#     USERNAME_FIELD = 'emp_id'
#     REQUIRED_FIELDS = ['emp_name', 'email']

#     def __str__(self):
#         return self.emp_name

# User = get_user_model()

# class Timesheet(models.Model):
#     employee = models.ForeignKey(User, on_delete=models.CASCADE)
#     date = models.DateField()
#     project_name = models.CharField(max_length=255)
#     start_time = models.TimeField()
#     end_time = models.TimeField()
#     total_hours = models.FloatField()
#     comments = models.TextField(blank=True)
#     status = models.CharField(max_length=20, default='pending')  # Default value for status

#     def __str__(self):
#         return f"{self.employee} - {self.project_name} - {self.date}"



# from django.db import models

# class Employee(models.Model):
#     emp_id = models.CharField(max_length=10, primary_key=True)
#     emp_name = models.CharField(max_length=100)
#     email_id = models.EmailField(unique=True)
#     password = models.CharField(max_length=100)

from django.db import models
from django.utils import timezone

class Employee(models.Model):
    EMPLOYEE_STATUS_CHOICES = [
        ('Employee', 'Employee'),
        ('Manager', 'Manager'),
        ('Lead', 'Lead'),
    ]

    emp_id = models.CharField(max_length=10, primary_key=True)
    emp_name = models.CharField(max_length=100)
    email_id = models.EmailField(unique=True)
    password = models.CharField(max_length=100)
    joining_date = models.DateField(default=timezone.now)
    timestamp = models.DateTimeField(auto_now_add=True)
    person_status = models.CharField(max_length=10, choices=EMPLOYEE_STATUS_CHOICES, default='Employee')

    def __str__(self):
        return self.emp_id

class Timesheet(models.Model):
    emp = models.ForeignKey(Employee, on_delete=models.CASCADE)
    date = models.DateField()
    project_name = models.CharField(max_length=100)
    start_time = models.TimeField()
    end_time = models.TimeField()
    comments = models.TextField()
    total_hours = models.DecimalField(max_digits=5, decimal_places=2)
    lead_approval = models.CharField(max_length=20, choices=[ ('pending', 'pending'), ('approved', 'approved'), ('rejected', 'rejected')], default='pending')
    manager_approval = models.CharField(max_length=20, choices=[ ('pending', 'pending'), ('approved', 'approved'), ('rejected', 'rejected')], default='pending')
