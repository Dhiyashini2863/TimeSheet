# from rest_framework import serializers
# from django.contrib.auth import get_user_model
# from django.core.exceptions import ValidationError
# from django.contrib.auth.password_validation import validate_password
# from .models import Timesheet
# from datetime import datetime, timedelta

# User = get_user_model()

# class RegisterSerializer(serializers.ModelSerializer):
#     password = serializers.CharField(write_only=True)
#     role = serializers.ChoiceField(choices=[('employee', 'Employee'), ('lead', 'Lead'), ('manager', 'Manager')])

#     class Meta:
#         model = User
#         fields = ['emp_id', 'emp_name', 'email', 'password', 'role']

#     def create(self, validated_data):
#         user = User.objects.create_user(
#             emp_id=validated_data['emp_id'],
#             emp_name=validated_data['emp_name'],
#             email=validated_data['email'],
#             password=validated_data['password'],
#             role=validated_data['role']
#         )
#         return user

# class LoginSerializer(serializers.Serializer):
#     emp_id = serializers.CharField()
#     password = serializers.CharField()

# class TimesheetSerializer(serializers.ModelSerializer):
#     employee_id = serializers.CharField()  # Input field for employee_id
#     employee_name = serializers.ReadOnlyField(source='employee.emp_name')  # Read-only field for employee_name

#     class Meta:
#         model = Timesheet
#         fields = ['id', 'employee_id', 'employee_name', 'date', 'project_name', 'start_time', 'end_time', 'total_hours', 'comments', 'status']
#         read_only_fields = ['status']  # Status should be read-only

#     def validate(self, data):
#         if data['start_time'] >= data['end_time']:
#             raise serializers.ValidationError("End time must be after start time.")
#         return data

#     def calculate_hours(self, start_time, end_time):
#         """Calculate total hours between two time objects."""
#         today = datetime.today().date()
#         start_datetime = datetime.combine(today, start_time)
#         end_datetime = datetime.combine(today, end_time)
        
#         # Handle crossing midnight
#         if end_datetime < start_datetime:
#             end_datetime += timedelta(days=1)
        
#         duration = end_datetime - start_datetime
#         return duration.total_seconds() / 3600

#     def create(self, validated_data):
#         employee_id = validated_data.pop('employee_id')
#         start_time = validated_data['start_time']
#         end_time = validated_data['end_time']

#         try:
#             employee = User.objects.get(emp_id=employee_id)
#         except User.DoesNotExist:
#             raise serializers.ValidationError({"employee_id": "Employee with this ID does not exist."})
        
#         # Calculate total_hours
#         total_hours = self.calculate_hours(start_time, end_time)
#         validated_data['total_hours'] = total_hours
#         validated_data['employee'] = employee

#         return super().create(validated_data)

#     def to_representation(self, instance):
#         representation = super().to_representation(instance)
#         representation['employee_id'] = instance.employee.emp_id  # Correctly include employee_id in response
#         return representation

    
# class ResetPasswordSerializer(serializers.Serializer):
#     emp_id = serializers.CharField(max_length=100)
#     new_password = serializers.CharField(max_length=128)

#     def validate_emp_id(self, value):
#         if not User.objects.filter(emp_id=value).exists():
#             raise serializers.ValidationError("Employee ID does not exist.")
#         return value

#     def validate_new_password(self, value):
#         try:
#             validate_password(value)
#         except ValidationError as e:
#             raise serializers.ValidationError(e.messages)
#         return value



from rest_framework import serializers
from .models import Employee, Timesheet
from django.contrib.auth.hashers import make_password
from django.core.exceptions import ValidationError
from django.contrib.auth.password_validation import validate_password

class LoginSerializer(serializers.Serializer):
    emp_id = serializers.CharField()
    password = serializers.CharField()

class EmployeeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Employee
        fields = '__all__'

class TimesheetSerializer(serializers.ModelSerializer):
    emp_id = serializers.CharField(source='emp.emp_id', read_only=True)
    emp_name = serializers.CharField(source='emp.emp_name', read_only=True)
    emp = serializers.PrimaryKeyRelatedField(queryset=Employee.objects.all(), write_only=True)

    class Meta:
        model = Timesheet
        fields = ['id', 'emp', 'emp_id', 'emp_name', 'date', 'project_name', 'start_time', 'end_time', 'comments', 'total_hours', 'lead_approval', 'manager_approval']

class ResetPasswordSerializer(serializers.Serializer):
    emp_id = serializers.CharField(max_length=100)
    new_password = serializers.CharField(max_length=128)

    def validate_emp_id(self, value):
        if not Employee.objects.filter(emp_id=value).exists():
            raise serializers.ValidationError("Employee ID does not exist.")
        return value

    def validate_new_password(self, value):
        try:
            validate_password(value)
        except ValidationError as e:
            raise serializers.ValidationError(e.messages)
        return value





