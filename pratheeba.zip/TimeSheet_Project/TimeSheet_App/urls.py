# from django.urls import path
# from .views import RegisterView, LoginView, TimesheetView, LeadTimesheetView, ManagerTimesheetView, ResetPasswordView, UserDetailsView

# urlpatterns = [
#     path('register/', RegisterView.as_view(), name='register'),
#     path('login/', LoginView.as_view(), name='login'),
#     path('timesheets/', TimesheetView.as_view(), name='timesheets'),
#     path('lead-timesheets/', LeadTimesheetView.as_view(), name='lead-timesheets'),
#     path('manager-timesheets/', ManagerTimesheetView.as_view(), name='manager-timesheets'),
#     path('reset-password/', ResetPasswordView.as_view(), name='reset-password'),
#     path('user-details/', UserDetailsView.as_view(), name='user-details'),
# ]


# from django.urls import path
# from .views import RegisterView, LoginView, TimesheetView

# urlpatterns = [
#     path('register/', RegisterView.as_view(), name='register'),
#     path('login/', LoginView.as_view(), name='login'),
#     path('timesheet/', TimesheetView.as_view(), name='timesheet'),
#     # Add other URLs here
# ]
from django.urls import path
from .views import RegisterView, LoginView, TimesheetView, LeadTimesheetView, ManagerTimesheetView, ResetPasswordView, UserDetailsView

urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('login/', LoginView.as_view(), name='login'),
    path('user-details/', UserDetailsView.as_view(), name='user-details'),
    path('timesheet/', TimesheetView.as_view(), name='timesheet'),
    path('lead-timesheets/', LeadTimesheetView.as_view(), name='lead-timesheets'),
    path('lead-timesheets/<int:timesheet_id>/', LeadTimesheetView.as_view(), name='lead-timesheet-update'),
    path('manager-timesheets/', ManagerTimesheetView.as_view(), name='manager-timesheets-list'),
    path('manager-timesheets/<int:timesheet_id>/', ManagerTimesheetView.as_view(), name='manager-timesheet-detail'),
    path('reset-password/', ResetPasswordView.as_view(), name='reset-password'),
]




