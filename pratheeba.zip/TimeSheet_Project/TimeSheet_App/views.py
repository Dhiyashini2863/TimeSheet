# from rest_framework import generics, serializers
# from rest_framework.permissions import AllowAny
# from rest_framework.response import Response
# from rest_framework.permissions import IsAuthenticated
# from rest_framework.views import APIView
# from rest_framework_simplejwt.tokens import RefreshToken
# from django.http import JsonResponse
# from django.contrib.auth.decorators import login_required
# from .models import Employee, Timesheet
# from rest_framework.exceptions import ValidationError
# from .serializers import RegisterSerializer, LoginSerializer, TimesheetSerializer, ResetPasswordSerializer
# from django.contrib.auth import get_user_model

# User = get_user_model()

# class RegisterView(generics.CreateAPIView):
#     serializer_class = RegisterSerializer
#     permission_classes = [AllowAny]

# class LoginView(generics.GenericAPIView):
#     serializer_class = LoginSerializer
#     permission_classes = [AllowAny]

#     def post(self, request, *args, **kwargs):
#         serializer = self.get_serializer(data=request.data)
#         serializer.is_valid(raise_exception=True)
#         emp_id = serializer.validated_data['emp_id']
#         password = serializer.validated_data['password']
#         user = User.objects.filter(emp_id=emp_id).first()

#         if user and user.check_password(password):
#             refresh = RefreshToken.for_user(user)
#             return Response({
#                 'access': str(refresh.access_token),
#                 'refresh': str(refresh),
#                 'role': user.role
#             })
#         return Response({'error': 'Invalid credentials'}, status=401)

# class TimesheetView(generics.ListCreateAPIView):
#     serializer_class = TimesheetSerializer

#     def get_queryset(self):
#         emp_id = self.request.query_params.get('emp', None)
#         if emp_id:
#             return Timesheet.objects.filter(employee__emp_id=emp_id)
#         return Timesheet.objects.all()

#     def perform_create(self, serializer):
#         emp_id = self.request.data.get('employee_id')
#         try:
#             employee = User.objects.get(emp_id=emp_id)
#             serializer.save(employee=employee)
#         except User.DoesNotExist:
#             raise serializers.ValidationError("Employee with this ID does not exist.")

# class LeadTimesheetView(generics.ListCreateAPIView):
#     serializer_class = TimesheetSerializer

#     def get_queryset(self):
#         user = self.request.user
#         if user.role == 'lead':
#             return Timesheet.objects.all()
#         return Timesheet.objects.none()

# class ManagerTimesheetView(generics.ListCreateAPIView):
#     serializer_class = TimesheetSerializer

#     def get_queryset(self):
#         user = self.request.user
#         if user.role == 'manager':
#             return Timesheet.objects.all()
#         return Timesheet.objects.none()

# class ResetPasswordView(generics.GenericAPIView):
#     serializer_class = ResetPasswordSerializer
#     permission_classes = [AllowAny]

#     def post(self, request, *args, **kwargs):
#         serializer = self.get_serializer(data=request.data)
#         serializer.is_valid(raise_exception=True)
#         emp_id = serializer.validated_data['emp_id']
#         new_password = serializer.validated_data['new_password']
#         user = User.objects.filter(emp_id=emp_id).first()

#         if user:
#             user.set_password(new_password)
#             user.save()
#             return Response({'message': 'Password reset successful'})
#         return Response({'error': 'Invalid employee ID'}, status=400)

# class UserDetailsView(APIView):
#     permission_classes = [IsAuthenticated]

#     def get(self, request):
#         user = {
#             'emp_id': request.user.emp_id,
#             'emp_name': request.user.emp_name,
#         }
#         return Response(user)



from rest_framework import status, generics
from rest_framework.response import Response
from rest_framework.views import APIView
from django.shortcuts import get_object_or_404 ,render
from django.contrib.auth.hashers import make_password, check_password
from django.contrib.auth import get_user_model
from rest_framework_simplejwt.tokens import RefreshToken
from .models import Employee, Timesheet
from .serializers import EmployeeSerializer, LoginSerializer, TimesheetSerializer, ResetPasswordSerializer
from rest_framework.permissions import AllowAny
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication


User = get_user_model()

class RegisterView(APIView):
    def post(self, request):
        data = request.data
        if data.get('password') != data.get('confirm_password'):
            return Response({"error": "Passwords do not match"}, status=status.HTTP_400_BAD_REQUEST)
        
        data['password'] = make_password(data['password'])
        serializer = EmployeeSerializer(data=data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class LoginView(APIView):
    serializer_class = LoginSerializer
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        emp_id = serializer.validated_data['emp_id']
        password = serializer.validated_data['password']
        
        try:
            user = Employee.objects.get(emp_id=emp_id)
            if check_password(password, user.password):
                refresh = RefreshToken()
                access_token = refresh.access_token
                # Manually encode the `emp_id` and `role` into the token's payload
                access_token['emp_id'] = emp_id
                access_token['role'] = user.person_status.lower()
                
                return Response({
                    'access': str(access_token),
                    'refresh': str(refresh),
                    'role': user.person_status.lower()
                })
        except Employee.DoesNotExist:
            pass
        
        return Response({'error': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)

class UserDetailsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        if isinstance(user, Employee):
            user_data = {
                'emp_id': user.emp_id,
                'emp_name': user.emp_name
            }
            return Response(user_data, status=status.HTTP_200_OK)
        return Response({'error': 'User not found'}, status=status.HTTP_404_NOT_FOUND)

class TimesheetView(APIView):
    def get(self, request):
        emp_id = request.query_params.get('emp')
        timesheets = Timesheet.objects.filter(emp__emp_id=emp_id) if emp_id else Timesheet.objects.all()
        serializer = TimesheetSerializer(timesheets, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        data = request.data
        total_hours = calculate_total_hours(data['start_time'], data['end_time'])
        data['total_hours'] = total_hours

        serializer = TimesheetSerializer(data=data)
        if serializer.is_valid():
            timesheet = serializer.save()
            response_data = TimesheetSerializer(timesheet).data
            response_data['total_hours'] = total_hours
            return Response(response_data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class ViewTimesheetView(APIView):
    def get(self, request):
        timesheets = Timesheet.objects.all()
        serializer = TimesheetSerializer(timesheets, many=True)
        if request.content_type == 'application/json':
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            return render(request, 'view_timesheet.html', {'timesheets': serializer.data})

class LeadTimesheetView(APIView):
    def get(self, request):
        timesheets = Timesheet.objects.select_related('emp').all()
        serializer = TimesheetSerializer(timesheets, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def put(self, request, timesheet_id):
        timesheet = get_object_or_404(Timesheet, id=timesheet_id)
        data = request.data
        timesheet.lead_approval = data.get('lead_approval', timesheet.lead_approval)
        timesheet.save()
        serializer = TimesheetSerializer(timesheet)
        return Response(serializer.data, status=status.HTTP_200_OK)

class ManagerTimesheetView(APIView):
    def get(self, request):
        timesheets = Timesheet.objects.select_related('emp').all()
        serializer = TimesheetSerializer(timesheets, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def put(self, request, timesheet_id):
        timesheet = get_object_or_404(Timesheet, id=timesheet_id)
        data = request.data
        timesheet.manager_approval = data.get('manager_approval', timesheet.manager_approval)
        timesheet.save()
        serializer = TimesheetSerializer(timesheet)
        return Response(serializer.data, status=status.HTTP_200_OK)

class ResetPasswordView(APIView):
    def post(self, request):
        serializer = ResetPasswordSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        emp_id = serializer.validated_data['emp_id']
        new_password = serializer.validated_data['new_password']
        user = get_object_or_404(Employee, emp_id=emp_id)
        user.password = make_password(new_password)
        user.save()
        return Response({"success": "Password updated successfully"}, status=status.HTTP_200_OK)

def calculate_total_hours(start_time, end_time):
    from datetime import datetime
    fmt = '%H:%M'
    start = datetime.strptime(start_time, fmt)
    end = datetime.strptime(end_time, fmt)
    total_hours = (end - start).seconds / 3600
    return round(total_hours, 2)
