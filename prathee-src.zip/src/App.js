import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './components/Login';
import EmployeeDashboard from './components/EmployeeDashboard';
import LeadDashboard from './components/LeadDashboard';
import ManagerDashboard from './components/ManagerDashboard';

function App() {
    return (
        <Router>
            <Routes>
                <Route path="/" element={<Login />} />
                <Route path="/employee/dashboard/*" element={<EmployeeDashboard />} />
                <Route path="/lead/dashboard/*" element={<LeadDashboard />} />
                <Route path="/manager/dashboard/*" element={<ManagerDashboard />} />
            </Routes>
        </Router>
    );
}

export default App;
