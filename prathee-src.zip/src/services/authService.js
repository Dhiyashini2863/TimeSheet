const API_URL = 'http://localhost:8000/api/';

const login = async (empId, password) => {
    try {
        const response = await fetch(`${API_URL}login/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ emp_id: empId, password: password }),
        });

        const data = await response.json();
        if (!response.ok) {
            console.error('Login failed:', data);
            throw new Error(data.detail || 'Login failed');
        }

        if (!data.role) {
            console.error('Role is missing in the response');
            throw new Error('Role is missing in the response');
        }

        return data;
    } catch (error) {
        console.error('Error during login:', error);
        throw error;
    }
};

const resetPassword = async (empId, newPassword) => {
    try {
        const response = await fetch(`${API_URL}reset-password/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ emp_id: empId, new_password: newPassword }),
        });

        const data = await response.json();
        if (!response.ok) {
            console.error('Password reset failed:', data);
            throw new Error(data.detail || 'Password reset failed');
        }
        return data;
    } catch (error) {
        console.error('Error during password reset:', error);
        throw error;
    }
};

const getUserDetails = async () => {
    try {
        const response = await fetch(`${API_URL}user-details/`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('accessToken')}`,
                'Content-Type': 'application/json',
            },
        });

        if (!response.ok) {
            const error = await response.text();
            console.error('Error during fetching user details:', error);
            throw new Error(error || 'Failed to fetch user details');
        }

        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error during fetching user details:', error);
        throw error;
    }
};




const authService = {
    login,
    resetPassword,
    getUserDetails,
};

export default authService;
