import React, { useState } from 'react';
import './Login.css';
import img from '../static/img/img.webp';
import img2 from '../static/img/img2.webp';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser, faLock, faKey } from '@fortawesome/free-solid-svg-icons';
import authService from '../services/authService';

const Login = () => {
    const [showLogin, setShowLogin] = useState(true);
    const [transitioning, setTransitioning] = useState(false);
    const [empId, setEmpId] = useState('');
    const [password, setPassword] = useState('');
    const [forgetEmpId, setForgetEmpId] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [message, setMessage] = useState('');

    const handleForgotPassword = () => {
        setTransitioning(true);
        setTimeout(() => {
            setShowLogin(false);
            setTransitioning(false);
        }, 500);
    };

    const handleBackToLogin = () => {
        setTransitioning(true);
        setTimeout(() => {
            setShowLogin(true);
            setTransitioning(false);
        }, 500);
    };

    const handleLogin = async (empId, password) => {
        try {
            const response = await authService.login(empId, password);
            localStorage.setItem('accessToken', response.access);
            localStorage.setItem('refreshToken', response.refresh);

            if (response.role === 'employee') {
                window.location.href = '/employee/dashboard';
            } else if (response.role === 'lead') {
                window.location.href = '/lead/dashboard';
            } else if (response.role === 'manager') {
                window.location.href = '/manager/dashboard';
            }
        } catch (error) {
            console.error('Error during login:', error);
            alert('Login failed. Please check your credentials and try again.');
        }
    };

    const handleResetPassword = async () => {
        if (newPassword === confirmPassword) {
            try {
                await authService.resetPassword(forgetEmpId, newPassword);
                setMessage('Password reset successful, please log in.');
                handleBackToLogin();
            } catch (error) {
                setMessage('Failed to reset password');
            }
        } else {
            setMessage('Passwords do not match');
        }
    };

    return (
        <div className={`login-container ${transitioning ? 'transitioning' : ''} ${!showLogin ? 'reset-password-active' : ''}`}>
            <div className="image-container">
                <img src={showLogin ? img : img2} alt="Background" />
            </div>
            <div className="form-container">
                {showLogin ? (
                    <div className="login-form">
                        <h2><FontAwesomeIcon icon={faUser} /> Login</h2>
                        <div className="input-group">
                            <FontAwesomeIcon icon={faUser} />
                            <input
                                type="text"
                                placeholder="Employee ID"
                                value={empId}
                                onChange={(e) => setEmpId(e.target.value)}
                            />
                        </div>
                        <div className="input-group">
                            <FontAwesomeIcon icon={faLock} />
                            <input
                                type="password"
                                placeholder="Password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                            />
                        </div>
                        <button onClick={() => handleLogin(empId, password)}>Login</button>
                        <p className="forgot-password" onClick={handleForgotPassword}>
                            Forgot Password?
                        </p>
                        {message && <p className="message">{message}</p>}
                    </div>
                ) : (
                    <div className="reset-password-form">
                        <h2><FontAwesomeIcon icon={faKey} /> Reset Password</h2>
                        <div className="input-group">
                            <FontAwesomeIcon icon={faUser} />
                            <input
                                type="text"
                                placeholder="Employee ID"
                                value={forgetEmpId}
                                onChange={(e) => setForgetEmpId(e.target.value)}
                            />
                        </div>
                        <div className="input-group">
                            <FontAwesomeIcon icon={faKey} />
                            <input
                                type="password"
                                placeholder="New Password"
                                value={newPassword}
                                onChange={(e) => setNewPassword(e.target.value)}
                            />
                        </div>
                        <div className="input-group">
                            <FontAwesomeIcon icon={faKey} />
                            <input
                                type="password"
                                placeholder="Confirm Password"
                                value={confirmPassword}
                                onChange={(e) => setConfirmPassword(e.target.value)}
                            />
                        </div>
                        <button onClick={handleResetPassword}>Reset Password</button>
                        <p className="back-to-login" onClick={handleBackToLogin}>
                            Back to Login
                        </p>
                        {message && <p className="message">{message}</p>}
                    </div>
                )}
            </div>
        </div>
    );
};

export default Login;
