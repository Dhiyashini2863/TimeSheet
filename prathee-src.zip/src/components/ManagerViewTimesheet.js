import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './ManagerViewTimesheet.css'; // Ensure correct path for styling

const ManagerViewTimesheet = () => {
    const [timesheets, setTimesheets] = useState([]);
    const [filteredTimesheets, setFilteredTimesheets] = useState([]);
    const [selectedDate, setSelectedDate] = useState(null);

    useEffect(() => {
        fetchTimesheets();
    }, []);

    const fetchTimesheets = async () => {
        try {
            const response = await axios.get('http://localhost:8000/api/manager-timesheets/');
            setTimesheets(response.data);
            setFilteredTimesheets(response.data);
        } catch (error) {
            console.error('Error fetching timesheets:', error);
        }
    };

    const handleApproval = async (timesheetId, approvalStatus) => {
        try {
            await axios.put(`http://localhost:8000/api/manager-timesheets/${timesheetId}/`, {
                manager_approval: approvalStatus,
            });
            fetchTimesheets(); // Refresh timesheets after approval/rejection
        } catch (error) {
            console.error('Error updating timesheet:', error);
        }
    };

    const handleDateChange = (e) => {
        const date = new Date(e.target.value);
        const formattedDate = date.toISOString().split('T')[0];
        setSelectedDate(formattedDate);

        const filtered = timesheets.filter(t => t.date === formattedDate);
        setFilteredTimesheets(filtered);
    };

    const handleShowAll = () => {
        setSelectedDate(null);
        setFilteredTimesheets(timesheets);
    };

    const renderTimesheetDetails = () => {
        if (!filteredTimesheets.length) return <p>No entries available</p>;

        return (
            <div className="timesheet-details">
                <h3>{selectedDate ? `Timesheet Details for ${selectedDate}` : 'All Timesheet Entries'}</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Employee ID</th>
                            <th>Employee Name</th>
                            <th>Date</th>
                            <th>Project Name</th>
                            <th>Start Time</th>
                            <th>End Time</th>
                            <th>Total Hours</th>
                            <th>Comments</th>
                            <th>Lead Approval</th>
                            <th>Manager Approval</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredTimesheets.map((timesheet) => (
                            <tr key={timesheet.id}>
                                <td>{timesheet.emp_id || 'N/A'}</td>
                                <td>{timesheet.emp_name || 'N/A'}</td>
                                <td>{timesheet.date}</td>
                                <td>{timesheet.project_name}</td>
                                <td>{timesheet.start_time}</td>
                                <td>{timesheet.end_time}</td>
                                <td>{timesheet.total_hours}</td>
                                <td>{timesheet.comments}</td>
                                <td>{timesheet.lead_approval}</td>
                                <td>
                                    {timesheet.manager_approval === 'pending' ? (
                                        <>
                                            <button onClick={() => handleApproval(timesheet.id, 'approved')}>Approve</button>
                                            <button onClick={() => handleApproval(timesheet.id, 'rejected')}>Reject</button>
                                        </>
                                    ) : (
                                        timesheet.manager_approval
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        );
    };

    return (
        <div className="manager-page-container">
            <h1>Hello, Manager</h1>
            <div className="date-selector">
                <input
                    type="date"
                    onChange={handleDateChange}
                />
                <button onClick={handleShowAll}>Show All</button>
            </div>
            {renderTimesheetDetails()}
        </div>
    );
};

export default ManagerViewTimesheet;
