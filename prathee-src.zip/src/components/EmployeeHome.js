import React, { useState, useEffect } from 'react';
import authService from '../services/authService';
import './EmployeeHome.css';

const EmployeeHome = () => {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true); // To handle loading state
    const [error, setError] = useState(null); // To handle errors

    useEffect(() => {
        const fetchUserDetails = async () => {
            try {
                setLoading(true); // Start loading
                const userDetails = await authService.getUserDetails();
                console.log('User Details:', userDetails); // Log user details
                setUser(userDetails);
            } catch (error) {
                console.error('Error fetching user details:', error);
                setError('Failed to fetch user details');
            } finally {
                setLoading(false); // Stop loading
            }
        };

        fetchUserDetails();
    }, []);

    if (loading) {
        return <p>Loading...</p>;
    }

    if (error) {
        return <p>{error}</p>;
    }

    if (!user) {
        return <p>No user data available.</p>;
    }

    return (
        <div className="home-container">
            <h1>Welcome, {user.emp_name}</h1>
            <p>Employee ID: {user.emp_id}</p>
            <p>We're glad to have you here. Please use the navigation bar to manage your tasks.</p>
        </div>
    );
};

export default EmployeeHome;
