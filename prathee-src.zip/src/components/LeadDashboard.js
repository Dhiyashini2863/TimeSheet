import React from 'react';
import { Route, Routes, NavLink } from 'react-router-dom';
import { FaHome, FaTable, FaSignOutAlt } from 'react-icons/fa'; // Import icons
import LeadHome from './LeadHome';
import LeadViewTimesheet from './LeadViewTimesheet';
import './LeadDashboard.css';

const LeadDashboard = () => {
  const handleLogout = () => {
    // Handle logout logic here
    window.location.href = '/'; // Redirect to login page
  };

  return (
    <div className="dashboard-container">
      <nav className="nav-bar">
        <ul>
          <li>
            <NavLink to="." end className={({ isActive }) => isActive ? 'active-link' : undefined}>
              <FaHome /> Home
            </NavLink>
          </li>
          <li>
            <NavLink to="view-timesheet" className={({ isActive }) => isActive ? 'active-link' : undefined}>
              <FaTable /> View Timesheet
            </NavLink>
          </li>
          <li>
            <a href="#" onClick={handleLogout}>
              <FaSignOutAlt /> Logout
            </a>
          </li>
        </ul>
      </nav>
      <div className="content-container">
        <Routes>
          <Route path="/" element={<LeadHome />} />
          <Route path="view-timesheet" element={<LeadViewTimesheet />} />
        </Routes>
      </div>
    </div>
  );
};

export default LeadDashboard;
