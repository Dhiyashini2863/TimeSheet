import React, { useState } from 'react';
import authService from '../services/authService';
import { useNavigate } from 'react-router-dom';
import './Register.css';

function Register() {
  const [empId, setEmpId] = useState('');
  const [empName, setEmpName] = useState('');
  const [emailId, setEmailId] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [role, setRole] = useState('employee');
  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      alert("Passwords do not match");
      return;
    }
    try {
      const userData = {
        emp_id: empId,
        emp_name: empName,
        email: emailId,
        password,
        confirm_password: confirmPassword,
        status: role
      };
      await authService.register(userData);
      alert("Registration successful");
      navigate('/login');
    } catch (error) {
      console.error("Error registering", error.response ? error.response.data : error.message);
      alert("Error registering");
    }
  };

  return (
    <div className="register-container">
      <h2>Register</h2>
      <form onSubmit={handleRegister}>
        <label>Employee ID:</label>
        <input type="text" value={empId} onChange={(e) => setEmpId(e.target.value)} required />
        <label>Employee Name:</label>
        <input type="text" value={empName} onChange={(e) => setEmpName(e.target.value)} required />
        <label>Email ID:</label>
        <input type="email" value={emailId} onChange={(e) => setEmailId(e.target.value)} required />
        <label>Password:</label>
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        <label>Confirm Password:</label>
        <input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required />
        <label>Role:</label>
        <select value={role} onChange={(e) => setRole(e.target.value)}>
          <option value="employee">Employee</option>
          <option value="lead">Lead</option>
          <option value="manager">Manager</option>
        </select>
        <button type="submit">Register</button>
      </form>
    </div>
  );
}

export default Register;
