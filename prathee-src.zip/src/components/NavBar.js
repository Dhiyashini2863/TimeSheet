import React from 'react';
import { Link } from 'react-router-dom';
import './NavBar.css'; // Ensure you create this CSS file for styling

const NavBar = ({ role }) => {
  return (
    <nav className="navbar">
      <ul>
        {role === 'employee' && (
          <>
            <li>
              <Link to="/update-timesheet">Update Timesheet</Link>
            </li>
            <li>
              <Link to="/view-timesheet">View Timesheet</Link>
            </li>
          </>
        )}
        {role === 'lead' && (
          <>
            <li>
              <Link to="/view-timesheet">View Timesheet</Link>
            </li>
            <li>
              <Link to="/approve-reject-timesheet">Approve/Reject Timesheet</Link>
            </li>
          </>
        )}
        {role === 'manager' && (
          <>
            <li>
              <Link to="/view-timesheet">View Timesheet</Link>
            </li>
            <li>
              <Link to="/approve-reject-timesheet">Approve/Reject Timesheet</Link>
            </li>
            <li>
              <Link to="/manage-employees">Manage Employees</Link>
            </li>
          </>
        )}
        <li>
          <Link to="/logout">Logout</Link>
        </li>
      </ul>
    </nav>
  );
};

export default NavBar;
