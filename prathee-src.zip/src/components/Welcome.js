// src/components/Welcome.js
import React from 'react';
import { Link } from 'react-router-dom';
import './Welcome.css';

const Welcome = () => {
  return (
    <div className="welcome-container">
      <h1>Welcome to the Timesheet App</h1>
      <div className="welcome-buttons">
        <Link to="/login" className="btn">Sign In</Link>
        <Link to="/register" className="btn">Sign Up</Link>
      </div>
    </div>
  );
};

export default Welcome;
