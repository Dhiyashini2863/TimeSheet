import axios from 'axios';
const API_URL = 'http://localhost:8000/api/timesheets/';

const timesheetService = {
    addTimesheet: (timesheetData) => {
        return axios.post(API_URL, timesheetData, {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        });
    },
    getTimesheets: () => {
        return axios.get(API_URL, {
            headers: {
                'Accept': 'application/json'
            }
        });
    },
    approveTimesheet: (id) => {
        return axios.patch(`${API_URL}${id}/approve/`, null, {
            headers: {
                'Accept': 'application/json'
            }
        });
    },
    rejectTimesheet: (id) => {
        return axios.patch(`${API_URL}${id}/reject/`, null, {
            headers: {
                'Accept': 'application/json'
            }
        });
    }
};

export default timesheetService;
