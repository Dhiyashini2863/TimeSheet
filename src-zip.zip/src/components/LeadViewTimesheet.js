import React, { useState, useEffect } from 'react';
import timesheetService from '../services/timesheetService'; // Use timesheetService
import './LeadViewTimesheet.css';

const LeadViewTimesheet = () => {
  const [timesheets, setTimesheets] = useState([]);

  useEffect(() => {
    const fetchTimesheets = async () => {
      try {
        const response = await timesheetService.getTimesheets(); // Use timesheetService
        setTimesheets(response.data);
      } catch (error) {
        console.error('Error fetching timesheets:', error);
      }
    };

    fetchTimesheets();
  }, []);

  const handleApproval = async (id) => {
    try {
      await timesheetService.approveTimesheet(id); // Use timesheetService
      const updatedTimesheets = timesheets.map((timesheet) =>
        timesheet.id === id ? { ...timesheet, status: 'approved' } : timesheet
      );
      setTimesheets(updatedTimesheets);
    } catch (error) {
      console.error('Error approving timesheet:', error);
    }
  };

  const handleRejection = async (id) => {
    try {
      await timesheetService.rejectTimesheet(id); // Use timesheetService
      const updatedTimesheets = timesheets.map((timesheet) =>
        timesheet.id === id ? { ...timesheet, status: 'rejected' } : timesheet
      );
      setTimesheets(updatedTimesheets);
    } catch (error) {
      console.error('Error rejecting timesheet:', error);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'approved':
        return 'green';
      case 'pending':
        return 'yellow';
      case 'rejected':
        return 'red';
      default:
        return 'grey';
    }
  };

  return (
    <div className="view-timesheet-container">
      <div className="headerr">
        <h2>View Timesheets</h2>
      </div>
      <table className="timesheet-table">
        <thead>
          <tr>
            <th>Employee ID</th>
            <th>Employee Name</th>
            <th>Date</th>
            <th>Project Name</th>
            <th>Start Time</th>
            <th>End Time</th>
            <th>Total Hours</th>
            <th>Description</th>
            <th>Timestamp</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {timesheets.map((timesheet) => (
            <tr key={timesheet.id}>
              <td>{timesheet.employee_id}</td>
              <td>{timesheet.employee_name}</td>
              <td>{timesheet.date}</td>
              <td>{timesheet.project_name}</td>
              <td>{timesheet.start_time}</td>
              <td>{timesheet.end_time}</td>
              <td>{timesheet.total_hours}</td>
              <td>{timesheet.description}</td>
              <td>{timesheet.timestamp}</td>
              <td style={{ color: getStatusColor(timesheet.status) }}>{timesheet.status}</td>
              <td>
                {timesheet.status === 'pending' && (
                  <>
                    <button className="approve-btn" onClick={() => handleApproval(timesheet.id)}>Approve</button>
                    <button className="reject-btn" onClick={() => handleRejection(timesheet.id)}>Reject</button>
                  </>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default LeadViewTimesheet;
