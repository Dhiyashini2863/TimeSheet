import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import authService from '../services/authService'; // Adjust the path as needed
import './ResetPassword.css'; // Add this line to the top of ResetPassword.js

const ResetPassword = () => {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();
  
  // Regular expression to validate the initial password format
  const passwordFormatRegex = /^[#][a-zA-Z]{3}[@][123]$/;

  const handleSubmit = async (event) => {
    event.preventDefault();

    // Validate that the initial password is in the correct format
    if (!passwordFormatRegex.test(password)) {
      setError('Password must be in the format [#][first three letters of your name][@][123]');
      return;
    }

    // Check if passwords match
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    try {
      // Call your API or service to reset the password
      const userId = authService.getCurrentUserId(); // Get the current user's ID
      await authService.resetPassword({ userId, password });

      // Redirect to login page after successful password reset
      navigate('/login');
    } catch (err) {
      setError('Failed to reset password. Please try again.');
    }
  };

  return (
    <div>
      <h2>Reset Password</h2>
      {error && <p className="error">{error}</p>}
      <form onSubmit={handleSubmit}>
        <label>
          New Password:
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </label>
        <label>
          Confirm Password:
          <input
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
          />
        </label>
        <button type="submit">Reset Password</button>
      </form>
    </div>
  );
};

export default ResetPassword;
