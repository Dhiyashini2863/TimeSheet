import React, { useState, useEffect } from 'react';
import authService from '../services/authService';
import timesheetService from '../services/timesheetService';
import './ViewTimesheet.css';

const ViewTimesheet = () => {
  const [timesheets, setTimesheets] = useState([]);

  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        const userDetails = await authService.getUserDetails();
        fetchTimesheets(userDetails.emp_id);
      } catch (error) {
        console.error('Error fetching user details:', error);
      }
    };

    const fetchTimesheets = async (empId) => {
      try {
        const response = await timesheetService.getTimesheets(empId);
        setTimesheets(response.data);
      } catch (error) {
        console.error('Error fetching timesheets:', error);
      }
    };

    fetchUserDetails();
  }, []);

  const getStatusColor = (status) => {
    switch (status) {
      case 'approved':
        return 'green';
      case 'pending':
        return 'yellow';
      case 'rejected':
        return 'red';
      default:
        return 'grey';
    }
  };

  return (
    <div className="view-timesheet-container">
      <div className="headerr">
        <h2>View Timesheet</h2>
      </div>
      <table className="timesheet-table">
        <thead>
          <tr>
            <th>Date</th>
            <th>Project Name</th> 
            <th>Start Time</th>
            <th>End Time</th>
            <th>Total Hours</th>
            <th>Description</th>
            <th>Timestamp</th> 
            <th>Lead Status</th>
            <th>Manager Status</th>
          </tr>
        </thead>
        <tbody>
          {timesheets.map((timesheet) => (
            <tr key={timesheet.id}>
              <td>{timesheet.date}</td>
              <td>{timesheet.project_name}</td>
              <td>{timesheet.start_time}</td>
              <td>{timesheet.end_time}</td>
              <td>{timesheet.total_hours}</td>
              <td>{timesheet.description}</td>
              <td>{timesheet.timestamp}</td>
              <td style={{ color: getStatusColor(timesheet.lead_status) }}>
                {timesheet.lead_status}
              </td>
              <td style={{ color: getStatusColor(timesheet.manager_status) }}>
                {timesheet.manager_status}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ViewTimesheet;
