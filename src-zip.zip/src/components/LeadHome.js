import React, { useState, useEffect } from 'react';
import authService from '../services/authService';
import './LeadHome.css';

const LeadHome = () => {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        const userDetails = await authService.getUserDetails();
        setUser(userDetails);
      } catch (error) {
        console.error('Error fetching user details:', error);
      }
    };

    fetchUserDetails();
  }, []);

  if (!user) {
    return <p>Loading...</p>;
  }

  return (
    <div className="home-container">
      <h1>Welcome, {user.emp_name}</h1>
      <p>Employee ID: {user.emp_id}</p>
      <p>We're glad to have you here. Please use the navigation bar to manage your tasks.</p>
    </div>
  );
};

export default LeadHome;
