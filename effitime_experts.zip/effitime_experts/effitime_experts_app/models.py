# from django.db import models

# class Employee(models.Model):
#     emp_id = models.CharField(max_length=10, primary_key=True)
#     emp_name = models.CharField(max_length=100)
#     email_id = models.EmailField(unique=True)
#     password = models.CharField(max_length=100)

from django.db import models
from django.utils import timezone

class Employee(models.Model):
    EMPLOYEE_STATUS_CHOICES = [
        ('Employee', 'Employee'),
        ('Manager', 'Manager'),
        ('Lead', 'Lead'),
    ]

    emp_id = models.CharField(max_length=10, primary_key=True)
    emp_name = models.CharField(max_length=100)
    email_id = models.EmailField(unique=True)
    password = models.CharField(max_length=100)
    joining_date = models.DateField(default=timezone.now)
    timestamp = models.DateTimeField(auto_now_add=True)
    person_status = models.CharField(max_length=10, choices=EMPLOYEE_STATUS_CHOICES, default='Employee')

    def __str__(self):
        return self.emp_id


class Timesheet(models.Model):
    emp = models.ForeignKey(Employee, on_delete=models.CASCADE)
    date = models.DateField()
    project_name = models.CharField(max_length=100)
    start_time = models.TimeField()
    end_time = models.TimeField()
    comments = models.TextField()
    total_hours = models.DecimalField(max_digits=5, decimal_places=2)
    lead_approval = models.CharField(max_length=20,choices=[ ('pending', 'pending'),('approved', 'approved'),('rejected', 'rejected')],default='pending')
    manager_approval = models.CharField(max_length=20,choices=[ ('pending', 'pending'),('approved', 'approved'),('rejected', 'rejected')],default='pending')
