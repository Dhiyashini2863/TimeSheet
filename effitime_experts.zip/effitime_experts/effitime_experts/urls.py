from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('effitime_experts_app.urls')),  # Include the app-level urls.py
]
